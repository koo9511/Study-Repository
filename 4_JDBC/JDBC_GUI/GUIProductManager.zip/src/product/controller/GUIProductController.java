package product.controller;

import product.view.ProductView;

public class GUIProductController {

	public static void main(String[] args) {
		// GUI 상품관리 프로그램 실행
		new ProductView();

	}

}
