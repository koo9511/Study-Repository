A Pen created at CodePen.io. You can find this one at http://codepen.io/Elbone/pen/wjLxA.

 A sun to bring cheer to your day 