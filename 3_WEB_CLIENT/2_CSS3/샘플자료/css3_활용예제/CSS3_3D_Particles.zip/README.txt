A Pen created at CodePen.io. You can find this one at http://codepen.io/timohausmann/pen/zxBnd.

 New particle divs are constantly created via JS. The animation happens via CSS: transitioning the particles to random transform values.