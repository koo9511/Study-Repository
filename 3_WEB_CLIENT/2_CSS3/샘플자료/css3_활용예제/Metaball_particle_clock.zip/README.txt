A Pen created at CodePen.io. You can find this one at http://codepen.io/rlemon/pen/vofKF.

 More playing with particles and forces and metaballs.  
colours are based on the current time (favoring the green in the rgb) 

Inspired by http://codepen.io/loktar00/