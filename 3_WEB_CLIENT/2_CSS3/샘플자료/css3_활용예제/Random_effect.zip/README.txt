A Pen created at CodePen.io. You can find this one at http://codepen.io/loktar00/pen/qieKA.

 Playing around with creating manual gradients.. this looked neat.