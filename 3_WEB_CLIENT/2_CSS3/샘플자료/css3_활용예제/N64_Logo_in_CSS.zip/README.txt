A Pen created at CodePen.io. You can find this one at http://codepen.io/adamstorr/pen/vIboj.

 I decided my first experiment with 3D in CSS would be recreating the classic N64 I'm so fond of.