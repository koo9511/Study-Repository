A Pen created at CodePen.io. You can find this one at http://codepen.io/joni/pen/dsGHw.

 Will now move on to 3D :D