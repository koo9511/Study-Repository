A Pen created at CodePen.io. You can find this one at http://codepen.io/webwoody/pen/Leydo.

 I wanted to demo the new HTML and CSS3 animations and transforms to a client using their own logo and only HTML / CSS. No javascript or flash was harmed in the making of this. I use a combination of gradients and a separate div to create the shader and glossy highlights.