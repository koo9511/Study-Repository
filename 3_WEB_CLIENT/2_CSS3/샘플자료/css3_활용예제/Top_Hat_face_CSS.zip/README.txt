A Pen created at CodePen.io. You can find this one at http://codepen.io/KFC-Bandit/pen/geJyd.

 A face and top hat made with CSS