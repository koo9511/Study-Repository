A Pen created at CodePen.io. You can find this one at http://codepen.io/hynden/pen/meniG.

 Inspired by http://drbl.in/ifmk