A Pen created at CodePen.io. You can find this one at http://codepen.io/dehash/pen/Bfory.

 more experimenting with displaying images in 3d slices    using css - development from   http://codepen.io/dehash/pen/mBnsG - practicing some more haml/scss too 