var foo = {
    name: 'foo',
    age: 30
};

console.log(foo.toString());

console.dir(foo);