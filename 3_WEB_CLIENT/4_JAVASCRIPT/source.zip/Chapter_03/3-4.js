// null 타입 변수 생성
var nullVar = null;

console.log(typeof nullVar === null); // false
console.log(nullVar === null); // true
