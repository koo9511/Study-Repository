var num = 5 / 2;

console.log(num); // 2.5
console.log(Math.floor(num)); // 2