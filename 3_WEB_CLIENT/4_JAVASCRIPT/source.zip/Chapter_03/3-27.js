// 숫자 메서드 호출
var num = 0.5;
console.log(num.toExponential(1)); // '5.0e-1'

// 문자열 메서드 호출
console.log("test".charAt(2)); // 's'