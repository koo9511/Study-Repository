var add1 = 1 + 2;
var add2 = 'my ' + 'string';
var add3 = 1 + 'string';
var add4 = 'string' + 2;

console.log(add1); // 3
console.log(add2); // my string
console.log(add3); // 1string
console.log(add4); // string2