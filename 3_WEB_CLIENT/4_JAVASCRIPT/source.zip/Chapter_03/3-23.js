var arr = ['zero', 'one', 'two', 'three'];

arr.splice(2, 1);
console.log(arr); // ["zero", "one", "three"]
console.log(arr.length); // 3