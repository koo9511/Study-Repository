var add = new Function('x', 'y', 'return x + y');
console.log(add(3, 4)); // 7
