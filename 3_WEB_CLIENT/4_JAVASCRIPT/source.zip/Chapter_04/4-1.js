// add() 함수 선언문
function add(x, y) {
    return x + y;
}

console.log(add(3, 4)); // 7