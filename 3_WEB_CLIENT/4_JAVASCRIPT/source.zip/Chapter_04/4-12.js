function add(x, y) {
    return x + y;
}

console.dir(add);
