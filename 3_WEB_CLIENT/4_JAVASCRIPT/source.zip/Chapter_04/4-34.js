// noReturnFunc() 함수
var noReturnFunc = function () {
    console.log('This function has no return statement.');
};

var result = noReturnFunc();
console.log(result);