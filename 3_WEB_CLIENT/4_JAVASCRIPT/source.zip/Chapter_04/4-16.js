(function (name) {
    console.log('This is the immediate function --> ' + name);
})('foo');