var foo = "I'm foo"; // 전역 변수 선언

console.log(foo); // I’m foo
console.log(window.foo); // I’m foo
